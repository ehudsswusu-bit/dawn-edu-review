# 曙光學習：網站品質與島嶼動作審查

這份程式以朋友提供的 [snapshot-2026-11-11](https://github.com/nashsung2-coder/dawn-edu-v4-staging/releases/tag/snapshot-2026-11-11) 整包快照為基準，並非遠端 main 的歷史同步；正式站以 https://edu.crestylon.org 為準。

先讀 [網站審查報告](review/SITE-REVIEW-2026-11-12.md) 與 [驗證紀錄](review/VALIDATION.md)。本輪改善學習進度與歷史可靠性、導引鍵盤操作、平板標題、步態與轉場，以及岩石／草叢視覺。尚有完整遊戲與跨裝置驗收待完成，勿直接部署。

## 本機預覽

需 Node.js；不需 npm install。

```sh
node tools/review-server.cjs
```

開啟 http://127.0.0.1:4175/ 。`review/quality-review.html` 是無帳號的岩石／草叢比較與角色工作室展示；完整島頁另依原站的登入、後端與資產設定運作。

```sh
node --test tests/quality.test.cjs review/character-studio/tests/*.test.cjs
```

`review/character-studio` 為前次 v0.2 獨立模型原型，含 JavaScript 原始碼與離線 HTML；沒有 Blender .blend 檔，也沒有在本輪自動取代正式島嶼角色。

## 基準與部署

- Release 原始檔保留於獨立資料夾，本輪只改審查副本。
- 遠端舊 main 仍為 c63714c，不應將其內容覆蓋正式站。
- 本輪不修改 Cloudflare、自動部署、資料庫權限或真實學習紀錄。
- GitHub 審查包若包含 patch，請在快照基準上 `git apply --check` 後，由網站維護者在測試分支實測，再自行整合部署。
