const {test} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs'), path = require('node:path'), vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const IQ = require('../js/core/island-quality.js');
const THREE = require('../review/character-studio/vendor/three.r128.min.cjs');
const read = name => fs.readFileSync(path.join(root, name), 'utf8');
function history() {
  const ctx = {URL, console}; vm.createContext(ctx);
  vm.runInContext(read('js/core/learn-history.js').replace(/export /g, ''), ctx);
  return ctx;
}
function progress(initial = {}, fail = false) {
  const store = new Map(Object.entries(initial));
  const ctx = {window:{}, localStorage:{getItem:k => store.get(k), setItem:(k,v) => {if(fail)throw Error('quota');store.set(k,v);},removeItem:k=>store.delete(k)}};
  vm.createContext(ctx); vm.runInContext(read('js/core/progress.js'), ctx);
  return {api:ctx.window.DawnProgress,store};
}
function cloud(data, updated_at, wait) {
  const q = {select(){return q;},eq(){return q;},async maybeSingle(){if(wait) await wait();return {data:{data,updated_at}};}};
  return {from:()=>q};
}
test('speed changes advance gait by just the new distance', () => {
  const phase = 1.2, result = IQ.advancePhase(phase, .02, 1.2);
  assert.ok(Math.abs(result - phase) < .06);
  assert.equal(IQ.advancePhase(result, 0, .7), result);
});
test('gait phase remains bounded after long sessions', () => {
  let phase=0; for(let i=0;i<100000;i++) phase=IQ.advancePhase(phase,.1,.9);
  assert.ok(phase>=0 && phase<Math.PI*2);
});
test('invalid distance never poisons the gait', () => {
  assert.equal(IQ.advancePhase(1,NaN,1),1); assert.equal(IQ.advancePhase(1,-1,1),1);
});
test('movement smoothing is independent of frame rate', () => {
  let a=0,b=0; for(let i=0;i<30;i++)a=IQ.damp(a,1,12,1/30);
  for(let i=0;i<120;i++)b=IQ.damp(b,1,12,1/120);
  assert.ok(Math.abs(a-b)<1e-12);
});
test('grass near paths is shorter without removing far-field variation', () => {
  assert.equal(IQ.grassHeight(0,4,1),.55); assert.ok(IQ.grassHeight(8,8,1)>.8);
});
test('sculpted stones reduce triangles and contain finite normals and colors', () => {
  const geo=IQ.stoneGeometry(THREE,.78,3), old=new THREE.SphereGeometry(.78,22,18);
  const triangles=g=>(g.index?g.index.count:g.attributes.position.count)/3;
  assert.ok(triangles(geo)<triangles(old));
  for(const name of ['position','normal','color'])assert.ok([...geo.attributes[name].array].every(Number.isFinite));
  assert.ok(geo.boundingSphere.radius>0); geo.dispose();old.dispose();
});
for(const topic of ['__proto__','constructor','toString'])test('history safely groups '+topic, () => {
  const html=history().renderHistoryList([{topic,type:'複習',detail:'完成'}]); assert.ok(html.includes(topic));
});
test('history rejects executable links but keeps relative learning links', () => {
  const render=history().renderHistoryList;
  for(const link of ['javascript:alert(1)','data:text/html,test',' javaScript:alert(1)','https://user:pass@example.com/']) {
    assert.ok(!render([{topic:'T',link}]).includes('<a '));
  }
  assert.ok(render([{topic:'T',link:'review.html?session=abc'}]).includes('https://edu.crestylon.org/pages/review.html?session=abc'));
});
test('history escapes both content and empty-state text', () => {
  const render=history().renderHistoryList;
  assert.ok(!render([], '<img src=x onerror=alert(1)>').includes('<img'));
  assert.ok(render([{topic:'<script>',detail:'**重點**'}]).includes('&lt;script&gt;'));
  assert.ok(render([{topic:'T',detail:'**重點**'}]).includes('<strong>重點</strong>'));
  assert.doesNotThrow(()=>render([null]));
});
test('progress reports storage failure to the caller', () => {
  assert.equal(progress({},true).api.save('test',{n:1}),false);
  assert.equal(progress().api.save('test',{n:1}),true);
});
test('sync compares time-zone offsets as instants, not text', async () => {
  const {api}=progress({dawn_progress_test:JSON.stringify({updatedAt:'2026-11-12T09:00:00Z',data:'newer'})});
  assert.equal(await api.syncFromCloud(cloud('older','2026-11-12T16:00:00+08:00'),'u','test'),null);
  assert.equal(api.load('test').data,'newer');
});
test('a malformed cloud timestamp cannot overwrite local progress', async () => {
  const {api}=progress();api.save('test','local');
  assert.equal(await api.syncFromCloud(cloud('bad','nonsense'),'u','test'),null);
  assert.equal(api.load('test').data,'local');
});
test('a local save while a cloud request is pending wins', async () => {
  const {api}=progress();
  await api.syncFromCloud(cloud('old','2020-01-01T00:00:00Z',()=>api.save('test','fresh')),'u','test');
  assert.equal(api.load('test').data,'fresh');
});
test('cloud upload preserves false, zero and empty-string values', async () => {
  for(const data of [false,0,'']){
    const {api}=progress();api.save('test',data);let sent;
    assert.equal(await api.pushToCloud({from:()=>({upsert:async row=>{sent=row;return {};}})},'u','test'),true);
    assert.equal(sent.data,data);
  }
});
test('all classic inline island scripts compile after the integration', () => {
  let count=0;
  for(const [,attrs,body] of read('pages/island-survival.html').matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)){
    if(/\bsrc=|type=["']module/.test(attrs)||!body.trim())continue;
    new vm.Script(body);count++;
  }
  assert.ok(count>0);
});
test('island loads quality helpers before using them', () => {
  const html=read('pages/island-survival.html');
  assert.ok(html.indexOf('src="../js/core/island-quality.js')<html.indexOf('var IQ ='));
  assert.ok(html.includes('fpsAcc.time += frameDt'));
});
test('integrated swimming blends without overwriting an almost-zero-weight pose', () => {
  const fn=read('pages/island-survival.html').match(/function poseBlTick\(t, P\)\{[\s\S]*?\n\}/)[0];
  const ctx={POSE:{mode:null},SWIM:{poseK:.0101}};vm.createContext(ctx);vm.runInContext(fn,ctx);
  const piv={};for(const name of ['shoulderL','shoulderR','elbowL','elbowR','thighL','thighR','shinL','shinR']){piv[name]=new THREE.Object3D();piv[name].rotation.x=.42;}
  ctx.poseBlTick(.4,piv);assert.ok(Math.abs(piv.shoulderL.rotation.x-.42)<.03);
  ctx.SWIM.poseK=1;ctx.poseBlTick(.4,piv);
  assert.ok(Math.abs(piv.thighL.rotation.x+piv.thighR.rotation.x)<1e-6);
});
function tabletHarness(actual) {
  let loads=0, loadHandler;
  const fr={title:'複習',style:{display:'block'},contentWindow:{location:{href:actual}},contentDocument:{title:'曙光寶庫 — 曙光學習',location:{href:actual}},getAttribute:()=> 'review.html',setAttribute:()=>{loads++;},addEventListener:(event,handler)=>{loadHandler=handler;}};
  const nodes={tabWinBody:{appendChild(){}},tabWinTitle:{textContent:''},tabHome:{},tabWin:{}};
  const ctx={TAB:{open:true,frames:{'review.html':fr}},document:{baseURI:'https://edu.crestylon.org/pages/island-survival.html',createElement:()=>fr},URL,$:id=>nodes[id],frameScrollTop(){},uiPush(){}};
  vm.createContext(ctx);
  const html=read('pages/island-survival.html');
  const start=html.indexOf('function tabSyncFrameTitle(fr){'),end=html.indexOf('\nfunction openTablet(url, title){',start);
  vm.runInContext(html.slice(start,end),ctx);
  return {ctx,fr,nodes,loads:()=>loads,handler:()=>loadHandler};
}
test('reopening review after an internal navigation reloads the requested app', () => {
  const h=tabletHarness('https://edu.crestylon.org/pages/knowledge.html?cat=test');
  h.ctx.tabOpenPage('review.html','複習');assert.equal(h.loads(),1);
});
test('reopening the same app preserves its frame without an unnecessary reload', () => {
  const h=tabletHarness('https://edu.crestylon.org/pages/review.html');
  h.ctx.tabOpenPage('review.html','複習');assert.equal(h.loads(),0);
});
test('tablet headings follow the real document while hidden frames cannot replace the heading', () => {
  const h=tabletHarness('https://edu.crestylon.org/pages/knowledge.html');
  h.ctx.tabSyncFrameTitle(h.fr);assert.equal(h.fr.title,'曙光寶庫');assert.equal(h.nodes.tabWinTitle.textContent,'曙光寶庫');
  h.fr.style.display='none';h.nodes.tabWinTitle.textContent='目前頁面';h.ctx.tabSyncFrameTitle(h.fr);
  assert.equal(h.nodes.tabWinTitle.textContent,'目前頁面');
});
