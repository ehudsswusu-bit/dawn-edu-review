const http=require('node:http'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css','.json':'application/json','.png':'image/png','.webp':'image/webp','.svg':'image/svg+xml','.glb':'model/gltf-binary'};
http.createServer((req,res)=>{
  let p;try{p=decodeURIComponent(new URL(req.url,'http://localhost').pathname);}catch{res.writeHead(400);return res.end();}
  if(p==='/')p='/review/quality-review.html';
  let file=path.resolve(root,'.'+p);
  if(!file.startsWith(root+path.sep)||p.includes('/.git')){res.writeHead(403);return res.end();}
  if(!path.extname(file)&&fs.existsSync(file+'.html'))file+='.html';
  fs.readFile(file,(err,data)=>{if(err){res.writeHead(404);return res.end('Not found');}res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream','Cache-Control':'no-store'});res.end(data);});
}).listen(4175,'127.0.0.1',()=>console.log('Review: http://127.0.0.1:4175/'));
