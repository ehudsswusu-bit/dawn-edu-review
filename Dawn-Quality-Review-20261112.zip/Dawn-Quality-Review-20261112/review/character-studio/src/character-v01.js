/* Original character and animation study. Three.js r128 is provided by the host. */
(function (scope, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else scope.DawnCharacterV01 = factory();
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const TAU = Math.PI * 2;
  const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
  const lerp = (a, b, t) => a + (b - a) * t;
  const smooth = x => { x = clamp(x, 0, 1); return x * x * (3 - 2 * x); };
  const damp = (a, b, rate, dt) => lerp(a, b, 1 - Math.exp(-rate * dt));
  const DEFAULTS = Object.freeze({
    skin: '#edbe9d', hair: '#5b352b', eyes: '#598b80',
    jacket: '#347c72', shirt: '#fff0d5', trousers: '#3b414c', boots: '#79533f',
    headScale: 1, height: 1, hairStyle: 'bob', backpack: true
  });
  const ACTIONS = Object.freeze(['idle', 'walk', 'run', 'jump', 'wave', 'sit', 'attack']);

  function createAvatar(THREE, options) {
    const config = Object.assign({}, DEFAULTS, options);
    config.headScale = clamp(Number(config.headScale) || 1, .85, 1.15);
    config.height = clamp(Number(config.height) || 1, .85, 1.15);
    const root = new THREE.Group(); root.name = 'DawnExplorer';
    root.scale.setScalar(config.height);
    const pivots = {}, materials = {}, geometryCache = new Map();
    const detail = new THREE.Group();
    function material(name, color, extra) {
      const m = new THREE.MeshStandardMaterial(Object.assign({ color, roughness: .82, metalness: 0 }, extra));
      m.name = name; materials[name] = m; return m;
    }
    const skin = material('Skin', config.skin);
    const blush = material('Cheek', '#db927e');
    const hair = material('Hair', config.hair, { roughness: .63 });
    const hairLight = material('HairHighlight', new THREE.Color(config.hair).lerp(new THREE.Color('#e3a97b'), .28));
    const jacket = material('Jacket', config.jacket);
    const shirt = material('Linen', config.shirt);
    const dark = material('Trousers', config.trousers);
    const leather = material('Leather', config.boots, { roughness: .72 });
    const sole = material('Sole', '#343330');
    const brass = material('Brass', '#cda66c', { metalness: .38, roughness: .43 });
    const white = material('EyeWhite', '#fff7e8', { roughness: .4 });
    const iris = material('Iris', config.eyes, { roughness: .34 });
    const ink = material('Ink', '#302c30', { roughness: .55 });
    const glint = material('Glint', '#ffffff', { roughness: .15, emissive: '#c5ddd4', emissiveIntensity: .2 });
    function group(name, parent, x=0, y=0, z=0) {
      const g = new THREE.Group(); g.name = name; g.position.set(x,y,z); parent.add(g); pivots[name] = g; return g;
    }
    function mesh(name, geometry, mat, parent, x=0, y=0, z=0, scale) {
      const m = new THREE.Mesh(geometry, mat); m.name = name;
      m.position.set(x,y,z); if (scale) m.scale.set(...scale);
      m.castShadow = true; m.receiveShadow = true; parent.add(m); return m;
    }
    function sphere(name, mat, parent, x,y,z,sx,sy,sz) {
      let geo = geometryCache.get('sphere');
      if (!geo) { geo = new THREE.SphereGeometry(1, 24, 16); geometryCache.set('sphere', geo); }
      return mesh(name, geo, mat, parent, x,y,z,[sx,sy,sz]);
    }
    function rounded(w,h,d,r=.04) {
      const key = [w,h,d,r].join('/'); if (geometryCache.has(key)) return geometryCache.get(key);
      const s = new THREE.Shape(), x=-w/2, y=-h/2;
      r = Math.min(r,w/2-.001,h/2-.001,d/2-.001);
      s.moveTo(x+r,y); s.lineTo(x+w-r,y); s.quadraticCurveTo(x+w,y,x+w,y+r);
      s.lineTo(x+w,y+h-r); s.quadraticCurveTo(x+w,y+h,x+w-r,y+h);
      s.lineTo(x+r,y+h); s.quadraticCurveTo(x,y+h,x,y+h-r);
      s.lineTo(x,y+r); s.quadraticCurveTo(x,y,x+r,y);
      const g = new THREE.ExtrudeGeometry(s,{depth:d-2*r,bevelEnabled:true,bevelThickness:r,bevelSize:r,bevelSegments:3,steps:1,curveSegments:4});
      g.translate(0,0,-(d-2*r)/2); g.computeVertexNormals(); geometryCache.set(key,g); return g;
    }
    function box(name, w,h,d,mat,parent,x,y,z,r) { return mesh(name,rounded(w,h,d,r),mat,parent,x,y,z); }
    function tube(name, points, radius, mat, parent) {
      return mesh(name,new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(...p))),16,radius,6,false),mat,parent);
    }
    function limb(name,length,rTop,rBottom,mat,parent) {
      const g = new THREE.LatheGeometry([
        new THREE.Vector2(.018,-length), new THREE.Vector2(rBottom*.7,-length+.012),
        new THREE.Vector2(rBottom,-length+.045),new THREE.Vector2(rTop,-.045),
        new THREE.Vector2(rTop*.72,-.012),new THREE.Vector2(.018,0)
      ],16); return mesh(name,g,mat,parent);
    }
    const hips = group('hips',root,0,.77,0);
    const chest = group('chest',hips,0,.02,0);
    sphere('Pelvis',dark,hips,0,-.015,0,.245,.16,.17);
    sphere('LinenBody',shirt,chest,0,.315,0,.285,.34,.185);
    box('JacketBack',.52,.53,.1,jacket,chest,0,.33,-.13,.035);
    [-1,1].forEach(side=> {
      const panel=box('JacketPanel'+side,.225,.52,.115,jacket,chest,side*.166,.32,.105,.035);
      panel.rotation.z=side*-.055;
      const lapel=box('Lapel'+side,.09,.24,.04,shirt,chest,side*.092,.48,.205,.012);
      lapel.rotation.z=side*-.25;
      box('Pocket'+side,.12,.12,.035,jacket,chest,side*.176,.225,.184,.013);
      tube('PocketStitch'+side,[[side*.23,.265,.206],[side*.18,.255,.21],[side*.12,.265,.206]],.005,brass,chest);
    });
    box('Belt',.49,.075,.34,leather,hips,0,.04,.01,.022);
    box('Buckle',.105,.075,.035,brass,hips,0,.04,.198,.012);
    box('BuckleInset',.054,.035,.014,leather,hips,0,.04,.223,.006);
    for(let i=0;i<3;i++) sphere('Button'+i,brass,chest,.042,.36-i*.095,.185,.014,.014,.009);
    sphere('Neck',skin,chest,0,.65,0,.095,.125,.09);
    const head = group('head',chest,0,.70,.005);
    head.scale.setScalar(config.headScale);
    sphere('Face',skin,head,0,.22,0,.355,.385,.302);
    [-1,1].forEach(side=> {
      sphere('Ear'+side,skin,head,side*.347,.205,-.005,.075,.106,.049);
      sphere('EarInner'+side,blush,head,side*.372,.205,.018,.033,.055,.021);
      const eye = group(side<0?'eyeL':'eyeR',head,side*.132,.235,.277);
      eye.rotation.y=side*.16;
      sphere('EyeWhite'+side,white,eye,0,0,0,.087,.109,.025);
      sphere('Iris'+side,iris,eye,.004,-.009,.022,.055,.077,.014);
      sphere('Pupil'+side,ink,eye,.005,-.007,.034,.026,.056,.008);
      sphere('EyeSpark'+side,glint,eye,-.017,.034,.043,.016,.023,.006);
      sphere('EyeSparkSmall'+side,glint,eye,.028,-.036,.041,.007,.009,.004);
      tube('UpperLid'+side,[[-.078,.035,.007],[0,.105,.004],[.074,.041,.01]],.009,ink,eye);
      tube('Brow'+side,[[side*.067,.398,.263],[side*.133,.421,.26],[side*.205,.404,.226]],.013,hair,head);
      sphere('Blush'+side,blush,head,side*.237,.133,.238,.047,.019,.008);
    });
    sphere('Nose',skin,head,0,.151,.306,.035,.043,.034);
    tube('Smile',[[-.058,.071,.281],[0,.054,.298],[.058,.071,.281]],.0085,ink,head);
    sphere('LowerLip',blush,head,0,.043,.285,.024,.006,.007);
    const hairRoot=group('hairRoot',head,0,0,0);
    // The cap is a hemisphere, leaving the face unobstructed.
    const cap = mesh('HairCap',new THREE.SphereGeometry(1,32,16,0,TAU,0,1.73),hair,hairRoot,0,.30,-.018,[.374,.36,.315]);
    const hairBack=group('hairBack',hairRoot,0,.45,-.21);
    sphere('BackHair',hair,hairBack,0,-.16,-.02,.325,config.hairStyle==='long'?.43:.28,.135);
    function lock(name,points,width,mat,parent) {
      // A curved, tapered hair ribbon with thickness, rather than intersecting cones.
      const curve=new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(...p)));
      const verts=[],indices=[],segments=12, around=8;
      for(let i=0;i<=segments;i++) {
        const t=i/segments, c=curve.getPoint(t), tangent=curve.getTangent(t);
        const across=new THREE.Vector3(1,0,0), normal=new THREE.Vector3().crossVectors(across,tangent).normalize();
        const taper=Math.max(.025,Math.pow(Math.sin((.14+t*.86)*Math.PI),.60));
        for(let j=0;j<around;j++) {
          const a=j/around*TAU;
          verts.push(c.x+Math.cos(a)*width*taper,c.y+normal.y*Math.sin(a)*width*.28*taper,c.z+normal.z*Math.sin(a)*width*.28*taper);
          if(i<segments) {const n=i*around+j,k=i*around+(j+1)%around;indices.push(n,k,n+around,k,k+around,n+around);}
        }
      }
      const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(verts,3));geo.setIndex(indices);geo.computeVertexNormals();
      return mesh(name,geo,mat,parent);
    }
    const fringe=group('hairFront',hairRoot,0,0,0);
    const specs=[
      [-.28,.10,-.09],[-.15,-.04,-.04],[-.01,-.07,.07],[.13,-.01,.09],[.26,.11,.06]
    ];
    specs.forEach((s,i)=>lock('Fringe'+i,[[s[0]*.63,.60,.06],[s[0],.48,.245],[s[0]+s[2],.315+s[1],.31]],.098,i===1?hairLight:hair,fringe));
    [-1,1].forEach(side=>lock('SideLock'+side,[[side*.28,.48,.1],[side*.355,.25,.115],[side*.326,.035,.12]],.067,hair,fringe));
    lock('CrownSweep',[[-.29,.50,-.06],[-.13,.635,-.015],[.14,.58,.05]],.028,hairLight,hairRoot);
    if(config.hairStyle==='pony') {
      const pony=group('ponytail',hairBack,0,-.02,-.10);
      lock('Ponytail',[[0,0,0],[.035,-.23,-.15],[.015,-.54,-.04]],.12,hair,pony);
      mesh('HairTie',new THREE.TorusGeometry(.09,.019,8,20),brass,pony,0,-.04,-.02).rotation.x=Math.PI/2;
    }
    const upperArm=.27, forearm=.25;
    [-1,1].forEach(side=>{
      const suffix=side<0?'L':'R';
      const shoulder=group('shoulder'+suffix,chest,side*.295,.55,0);
      shoulder.rotation.z=side*.10;
      sphere('ShoulderCloth'+suffix,jacket,shoulder,side*.015,-.035,0,.11,.115,.12);
      limb('UpperSleeve'+suffix,upperArm,.092,.082,jacket,shoulder);
      const elbow=group('elbow'+suffix,shoulder,0,-upperArm,0);
      sphere('ElbowJoint'+suffix,jacket,elbow,0,.015,0,.081,.083,.082);
      limb('ForeSleeve'+suffix,forearm,.079,.066,jacket,elbow);
      box('Cuff'+suffix,.145,.055,.15,shirt,elbow,0,-forearm+.02,0,.018);
      const hand=group('hand'+suffix,elbow,0,-forearm-.03,0);
      sphere('Palm'+suffix,skin,hand,0,-.025,.012,.064,.082,.055);
      sphere('Thumb'+suffix,skin,hand,-side*.053,-.007,.037,.027,.048,.029);
      const thigh=group('thigh'+suffix,hips,side*.153,-.015,0);
      limb('TrouserThigh'+suffix,.34,.115,.097,dark,thigh);
      const shin=group('shin'+suffix,thigh,0,-.34,0);
      sphere('Knee'+suffix,dark,shin,0,0,0,.094,.091,.096);
      limb('TrouserShin'+suffix,.32,.094,.074,dark,shin);
      const ankle=group('ankle'+suffix,shin,0,-.32,0);
      box('BootShaft'+suffix,.17,.19,.19,leather,ankle,0,.02,0,.032);
      box('BootToe'+suffix,.188,.14,.30,leather,ankle,0,-.025,.066,.038);
      box('BootSole'+suffix,.20,.045,.31,sole,ankle,0,-.09,.066,.016);
      for(let i=0;i<3;i++)box('Lace'+suffix+i,.10,.012,.012,shirt,ankle,0,.045-i*.027,.145-i*.016,.004);
      box('BootTab'+suffix,.045,.07,.025,brass,ankle,side*.095,.05,-.025,.007);
    });
    const backpack=group('backpack',chest,0,.32,-.225);
    backpack.visible=!!config.backpack;
    box('PackBody',.38,.43,.19,leather,backpack,0,0,-.055,.045);
    box('PackFlap',.405,.17,.21,jacket,backpack,0,.145,-.055,.034);
    box('PackPocket',.24,.16,.055,leather,backpack,0,-.07,-.165,.022);
    [-1,1].forEach(side=>{
      tube('Strap'+side,[[side*.17,.59,-.12],[side*.22,.45,.21],[side*.21,.17,.20],[side*.17,.12,-.12]],.022,leather,chest);
      box('PackBuckle'+side,.054,.075,.02,brass,backpack,side*.104,.06,-.17,.008);
    });
    detail.name='CharacterDetails';root.add(detail);
    root.updateMatrixWorld(true);
    return {
      root,pivots,materials,config,
      setColors(colors){Object.keys(colors).forEach(k=>{if(materials[k])materials[k].color.set(colors[k]);});},
      dispose(){
        const geometries=new Set(), mats=new Set();
        root.traverse(o=>{if(o.isMesh){geometries.add(o.geometry);(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>mats.add(m));}});
        geometries.forEach(g=>g.dispose());mats.forEach(m=>m.dispose());if(root.parent)root.parent.remove(root);
      }
    };
  }

  // Analytic sagittal two-bone IK. A level ankle prevents the boot from rotating into the floor.
  function solveLeg(y,z,upper=.34,lower=.32) {
    const distance=clamp(Math.hypot(y,z),.055,upper+lower-.001);
    const knee=Math.PI-Math.acos(clamp((upper*upper+lower*lower-distance*distance)/(2*upper*lower),-1,1));
    const hip=Math.atan2(-z,-y)-Math.acos(clamp((upper*upper+distance*distance-lower*lower)/(2*upper*distance),-1,1));
    return {hip,knee,ankle:-hip-knee};
  }
  class MotionController {
    constructor(avatar) {
      this.avatar=avatar;this.action='idle';this.time=0;this.actionTime=0;this.phase=0;
      this.speed=0;this.previousSpeed=0;this.blend=0;this.weights={idle:1};
      this.hair={x:0,v:0};this.reducedMotion=false;this.freeze=false;
      this.base=new Map();
      Object.values(avatar.pivots).forEach(p=>this.base.set(p,{p:p.position.clone(),r:p.rotation.clone(),s:p.scale.clone()}));
    }
    setAction(action) {
      if(!ACTIONS.includes(action))throw new Error('Unknown action: '+action);
      if(this.action!==action){this.action=action;this.actionTime=0;}
    }
    reset(){this.time=0;this.phase=0;this.speed=0;this.previousSpeed=0;this.actionTime=0;this.weights={idle:1};this.hair={x:0,v:0};}
    update(dt,input={}) {
      if(this.freeze)return;
      if(!Number.isFinite(dt)||dt<0)throw new Error('Animation dt must be finite and non-negative');
      // Bounded substeps keep springs stable after a hidden tab or a dropped frame.
      let remain=Math.min(dt,.15);
      while(remain>1e-8){const step=Math.min(remain,1/60);this._step(step,input);remain-=step;}
      this.avatar.root.updateMatrixWorld(true);
    }
    _step(dt,input) {
      const P=this.avatar.pivots;
      this.time+=dt;this.actionTime+=dt;
      const target=Number.isFinite(input.speed)?Math.max(0,input.speed):(this.action==='run'?1.65:this.action==='walk'?.65:0);
      this.previousSpeed=this.speed;this.speed=damp(this.speed,target,7.5,dt);
      const accel=(this.speed-this.previousSpeed)/dt;
      const run=smooth((this.speed-.75)/.90), stride=lerp(.44,.66,run);
      this.phase=(this.phase+this.speed/stride*TAU*dt)%TAU;
      const locomotion=clamp(this.speed/.45,0,1), t=this.time;
      ACTIONS.forEach(a=>{this.weights[a]=damp(this.weights[a]||0,this.action===a?1:0,11,dt);});
      this.base.forEach((b,p)=>{p.position.copy(b.p);p.rotation.copy(b.r);p.scale.copy(b.s);});
      const breath=this.reducedMotion?0:Math.sin(t*1.8)*.009*(1-locomotion);
      const bob=-Math.cos(this.phase*2)*lerp(.012,.025,run)*locomotion;
      const gaitDip=locomotion*lerp(.035,.075,run);
      P.hips.position.y+=breath+bob-gaitDip;
      P.hips.rotation.y=Math.sin(this.phase)*.035*locomotion;
      P.hips.rotation.z=Math.sin(this.phase)*.027*locomotion;
      P.chest.rotation.x=.025*locomotion+clamp(accel*.008,-.06,.06);
      P.chest.rotation.y=-P.hips.rotation.y*.7;
      P.head.rotation.x=-P.chest.rotation.x*.55;
      if(!this.reducedMotion)P.head.rotation.z=Math.sin(t*.75)*.017*(1-locomotion);
      ['L','R'].forEach((side,i)=>{
        const cycle=((this.phase/TAU+i*.5)%1+1)%1, contact=.62;
        let z,y;
        if(cycle<contact){z=stride*(.5-cycle/contact);y=0;}
        else{const u=(cycle-contact)/(1-contact);z=stride*(-.5+smooth(u));y=Math.sin(Math.PI*u)*lerp(.10,.19,run);}
        const pose=solveLeg(-.625+y-bob+gaitDip,z*locomotion);
        P['thigh'+side].rotation.x=pose.hip;
        P['shin'+side].rotation.x=pose.knee;
        P['ankle'+side].rotation.x=pose.ankle;
        P['shoulder'+side].rotation.x=-Math.sin(this.phase+i*Math.PI)*lerp(.30,.59,run)*locomotion;
        P['elbow'+side].rotation.x=-.12-locomotion*lerp(.12,.55,run);
      });
      const jw=this.weights.jump||0, jumpP=(this.actionTime%1.65)/1.65;
      const flight=smooth((jumpP-.14)/.12)*(1-smooth((jumpP-.72)/.13));
      const arc=Math.sin(clamp((jumpP-.18)/.62,0,1)*Math.PI)*.43;
      const crouch=Math.sin(clamp(jumpP/.18,0,1)*Math.PI)*.09;
      const landing=Math.sin(clamp((jumpP-.80)/.20,0,1)*Math.PI)*.075;
      P.hips.position.y+=(arc-crouch-landing)*jw;
      ['L','R'].forEach((side,i)=>{
        const hip=-.18-flight*(i?.32:.52), knee=.38+flight*(i?.45:.7)+crouch*4+landing*3;
        P['thigh'+side].rotation.x=lerp(P['thigh'+side].rotation.x,hip,jw);
        P['shin'+side].rotation.x=lerp(P['shin'+side].rotation.x,knee,jw);
        P['ankle'+side].rotation.x=lerp(P['ankle'+side].rotation.x,-hip-knee,jw);
        P['shoulder'+side].rotation.x=lerp(P['shoulder'+side].rotation.x,-flight*1.3,jw);
      });
      const wave=this.weights.wave||0;
      P.shoulderR.rotation.z=lerp(P.shoulderR.rotation.z,2.13,wave);
      P.shoulderR.rotation.x=lerp(P.shoulderR.rotation.x,-.22,wave);
      P.elbowR.rotation.x=lerp(P.elbowR.rotation.x,-.48,wave);
      P.handR.rotation.z=Math.sin(this.actionTime*9)*.32*wave;
      P.head.rotation.z-=.045*wave;
      const sit=this.weights.sit||0;
      P.hips.position.y-=.28*sit;P.chest.rotation.x-=.055*sit;
      ['L','R'].forEach(side=>{
        P['thigh'+side].rotation.x=lerp(P['thigh'+side].rotation.x,-1.40,sit);
        P['shin'+side].rotation.x=lerp(P['shin'+side].rotation.x,1.47,sit);
        P['ankle'+side].rotation.x=lerp(P['ankle'+side].rotation.x,-.07,sit);
        P['shoulder'+side].rotation.x=lerp(P['shoulder'+side].rotation.x,-.48,sit);
        P['elbow'+side].rotation.x=lerp(P['elbow'+side].rotation.x,-.60,sit);
      });
      const attack=this.weights.attack||0, ap=(this.actionTime%1.35)/1.35;
      const wind=smooth(ap/.30), slash=smooth((ap-.30)/.16), recover=smooth((ap-.53)/.47);
      const swing=lerp(-.8*wind,1.15,slash)*(1-recover);
      P.chest.rotation.y+=swing*.42*attack;
      P.shoulderR.rotation.x=lerp(P.shoulderR.rotation.x,-.9-swing,attack);
      P.shoulderR.rotation.z+=swing*.28*attack;
      P.elbowR.rotation.x=lerp(P.elbowR.rotation.x,-.7+slash*.38,attack*(1-recover));
      // Deterministic eyelids: open and close ease smoothly; no random frame-rate dependency.
      const blinkCycle=(t+.3)%4.6;
      const blink=blinkCycle<.17?Math.sin(blinkCycle/.17*Math.PI):0;
      P.eyeL.scale.y=P.eyeR.scale.y=1-blink*.94;
      const hairTarget=this.reducedMotion?0:clamp(accel*.008+this.speed*.045+arc*jw*.1,-.10,.20);
      this.hair.v+=((hairTarget-this.hair.x)*65-this.hair.v*14)*dt;
      this.hair.x+=this.hair.v*dt;
      P.hairBack.rotation.x=this.hair.x;
      P.hairFront.rotation.x=this.hair.x*.3;
      if(P.ponytail)P.ponytail.rotation.x=this.hair.x*1.6;
      P.backpack.rotation.x=this.hair.x*.28;
      // The seated preview supplies a bench. This module does not create world geometry.
    }
  }
  return {createAvatar,MotionController,solveLeg,DEFAULTS,ACTIONS};
});
