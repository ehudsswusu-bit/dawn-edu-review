/* Minimal glTF 2.0 binary exporter for this project's unskinned pivot hierarchy. */
(function(scope,factory){
  if(typeof module==='object'&&module.exports)module.exports=factory();
  else scope.DawnGLB=factory();
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  function exportGLB(root,clips=[]) {
    root.updateMatrixWorld(true);
    const gltf={asset:{version:'2.0',generator:'Dawn Character Studio 0.1'},scene:0,scenes:[{nodes:[0]}],nodes:[],meshes:[],materials:[],accessors:[],bufferViews:[],buffers:[]};
    const chunks=[],objects=[],nodeMap=new Map(),materialMap=new Map(),meshMap=new Map();let byteLength=0;
    function accessor(array,type,target,minMax=false){
      const alignment=(4-byteLength%4)%4;if(alignment){chunks.push(new Uint8Array(alignment));byteLength+=alignment;}
      const bytes=new Uint8Array(array.buffer,array.byteOffset,array.byteLength);
      const view={buffer:0,byteOffset:byteLength,byteLength:bytes.byteLength};if(target)view.target=target;
      gltf.bufferViews.push(view);chunks.push(bytes);byteLength+=bytes.byteLength;
      const count={SCALAR:1,VEC2:2,VEC3:3,VEC4:4}[type];
      const componentType=array instanceof Float32Array?5126:array instanceof Uint32Array?5125:array instanceof Uint16Array?5123:5121;
      const a={bufferView:gltf.bufferViews.length-1,componentType,count:array.length/count,type};
      if(minMax){a.min=Array(count).fill(Infinity);a.max=Array(count).fill(-Infinity);for(let i=0;i<array.length;i++){a.min[i%count]=Math.min(a.min[i%count],array[i]);a.max[i%count]=Math.max(a.max[i%count],array[i]);}}
      gltf.accessors.push(a);return gltf.accessors.length-1;
    }
    function material(m){
      if(materialMap.has(m))return materialMap.get(m);
      const c=m.color;
      const result={name:m.name||'Material',pbrMetallicRoughness:{baseColorFactor:[c.r,c.g,c.b,m.opacity],metallicFactor:m.metalness||0,roughnessFactor:m.roughness===undefined?.8:m.roughness},doubleSided:m.side===2};
      if(m.transparent){result.alphaMode='BLEND';}
      gltf.materials.push(result);const i=gltf.materials.length-1;materialMap.set(m,i);return i;
    }
    function walk(o){
      if(!o.visible)return null;
      const index=gltf.nodes.length;nodeMap.set(o,index);objects.push(o);
      const n={name:o.name||'Node',translation:o.position.toArray(),rotation:o.quaternion.toArray(),scale:o.scale.toArray()};gltf.nodes.push(n);
      if(o.isMesh){
        if(Array.isArray(o.material))throw new Error('Multi-material meshes are not supported by this exporter.');
        const key=o.geometry.uuid+'/'+o.material.uuid;
        if(meshMap.has(key))n.mesh=meshMap.get(key);
        else {
          const g=o.geometry,attributes={POSITION:accessor(new Float32Array(g.attributes.position.array),'VEC3',34962,true)};
          if(g.attributes.normal)attributes.NORMAL=accessor(new Float32Array(g.attributes.normal.array),'VEC3',34962);
          if(g.attributes.uv)attributes.TEXCOORD_0=accessor(new Float32Array(g.attributes.uv.array),'VEC2',34962);
          const pr={attributes,material:material(o.material),mode:4};
          if(g.index)pr.indices=accessor(g.index.array,'SCALAR',34963);
          gltf.meshes.push({name:o.name,primitives:[pr]});n.mesh=gltf.meshes.length-1;meshMap.set(key,n.mesh);
        }
      }
      const children=o.children.map(walk).filter(i=>i!==null);if(children.length)n.children=children;
      return index;
    }
    walk(root);
    if(clips.length)gltf.animations=clips.map(clip=>{
      const result={name:clip.name,samplers:[],channels:[]};
      clip.tracks.forEach(track=>{
        const node=nodeMap.get(track.object);if(node===undefined)return;
        const input=accessor(track.times,'SCALAR',null,true);
        const output=accessor(track.values,track.path==='rotation'?'VEC4':'VEC3');
        result.samplers.push({input,output,interpolation:'LINEAR'});
        result.channels.push({sampler:result.samplers.length-1,target:{node,path:track.path}});
      });return result;
    });
    gltf.buffers=[{byteLength}];
    const rawJSON=new TextEncoder().encode(JSON.stringify(gltf));
    const jsonLength=Math.ceil(rawJSON.length/4)*4,binLength=Math.ceil(byteLength/4)*4;
    const output=new ArrayBuffer(12+8+jsonLength+8+binLength),view=new DataView(output),bytes=new Uint8Array(output);
    view.setUint32(0,0x46546c67,true);view.setUint32(4,2,true);view.setUint32(8,output.byteLength,true);
    view.setUint32(12,jsonLength,true);view.setUint32(16,0x4e4f534a,true);bytes.fill(32,20,20+jsonLength);bytes.set(rawJSON,20);
    const binStart=20+jsonLength;view.setUint32(binStart,binLength,true);view.setUint32(binStart+4,0x004e4942,true);
    let cursor=binStart+8;chunks.forEach(c=>{bytes.set(c,cursor);cursor+=c.byteLength;});return output;
  }
  function bakeClips(avatar,MotionController,actions,fps=30){
    const snapshots=[];avatar.root.traverse(o=>snapshots.push([o,o.position.clone(),o.quaternion.clone(),o.scale.clone()]));
    try {
      return actions.map(name=>{
        snapshots.forEach(([o,p,q,s])=>{o.position.copy(p);o.quaternion.copy(q);o.scale.copy(s);});
        const controller=new MotionController(avatar);controller.setAction(name);
        for(let i=0;i<90;i++)controller.update(1/60);
        controller.time=0;controller.actionTime=0;controller.phase=0;
        if(controller.clocks)Object.keys(controller.clocks).forEach(key=>controller.clocks[key]=0);
        controller.transition=null;controller.update(1/6000);
        const duration=name==='jump'?1.65:name==='attack'?1.35:name==='idle'?4.6:name==='walk'?(.44/(.65*.62))*2:name==='run'?(.66/(1.65*.48))*2:2;
        const count=Math.round(duration*fps)+1,times=new Float32Array(count),tracks=[];
        const objects=Object.values(avatar.pivots);
        objects.forEach(object=>['translation','rotation','scale'].forEach(path=>tracks.push({object,path,times,values:new Float32Array(count*(path==='rotation'?4:3))})));
        for(let i=0;i<count;i++){
          times[i]=i*duration/(count-1);if(i)controller.update(duration/(count-1));
          tracks.forEach(track=>{
            const property=track.path==='translation'?'position':track.path==='rotation'?'quaternion':'scale';
            track.object[property].toArray(track.values,i*(track.path==='rotation'?4:3));
          });
        }
        // Close exported cycles over the final 120 ms. Quaternion signs are aligned before nlerp.
        tracks.forEach(track=>{
          const width=track.path==='rotation'?4:3;
          for(let i=0;i<count;i++){
            const u=Math.max(0,(times[i]-(duration-.12))/.12);if(!u)continue;
            const k=Math.min(1,u*u*(3-2*u)),offset=i*width;
            let sign=1;
            if(width===4){let dot=0;for(let j=0;j<4;j++)dot+=track.values[offset+j]*track.values[j];if(dot<0)sign=-1;}
            for(let j=0;j<width;j++)track.values[offset+j]+=(track.values[j]*sign-track.values[offset+j])*k;
            if(width===4){let length=0;for(let j=0;j<4;j++)length+=track.values[offset+j]**2;length=Math.sqrt(length);for(let j=0;j<4;j++)track.values[offset+j]/=length;}
          }
        });
        return {name,tracks};
      });
    } finally {snapshots.forEach(([o,p,q,s])=>{o.position.copy(p);o.quaternion.copy(q);o.scale.copy(s);});avatar.root.updateMatrixWorld(true);}
  }
  return {exportGLB,bakeClips};
});
