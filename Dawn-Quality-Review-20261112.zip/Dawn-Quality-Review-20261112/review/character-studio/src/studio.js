(function(){
  'use strict';
  const $=id=>document.getElementById(id);
  const T=window.THREE, C=window.DawnCharacter;
  const actionNames={idle:['◌','待機','呼吸與眨眼'],walk:['↟','走路','腳掌落地與擺臂'],run:['↠','跑步','重心前移與配件跟隨'],jump:['↑','跳躍','蓄力、騰空與落地'],wave:['✧','招手','肩肘與手腕協同'],sit:['⌑','坐下','平滑切換坐姿'],attack:['⌁','揮擊','預備、出力與收勢']};
  const palettes=[
    {name:'苔綠探險',jacket:'#347c72',hair:'#5b352b',eyes:'#598b80',shirt:'#fff0d5',trousers:'#3b414c',boots:'#79533f'},
    {name:'暖日旅人',jacket:'#c18b49',hair:'#382c29',eyes:'#896239',shirt:'#fff2db',trousers:'#535c64',boots:'#62483d'},
    {name:'暮色學者',jacket:'#71738d',hair:'#b6a28b',eyes:'#687897',shirt:'#f3e8db',trousers:'#393c50',boots:'#544b55'}
  ];
  let config={...C.DEFAULTS},avatar,motion,action='idle',paused=false,rate=1,autoRotate=false,wireframe=false;
  let motionVersion='optimized',sequenceOn=false,sequenceTime=0,sequenceIndex=0;
  const sequence=[['idle',1.5],['walk',2.6],['run',2.6],['idle',1.6],['jump',2.0],['wave',1.6],['sit',2.2],['attack',2],['idle',1.5]];
  let yaw=.48,pitch=.11,distance=4.8,targetYaw=yaw,targetPitch=pitch,targetDistance=distance;
  let renderer;
  try {renderer=new T.WebGLRenderer({canvas:$('scene'),antialias:true,alpha:false,preserveDrawingBuffer:false});}
  catch(error){$('error').hidden=false;$('error').textContent='無法啟動 3D 預覽。請確認瀏覽器支援 WebGL，或啟用硬體加速後重新載入。';return;}
  renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.8));
  renderer.outputEncoding=T.sRGBEncoding;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=.95;
  renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;
  const scene=new T.Scene();scene.background=new T.Color('#e7ece1');scene.fog=new T.Fog('#e7ece1',9,19);
  const camera=new T.PerspectiveCamera(34,1,.1,40);
  scene.add(new T.HemisphereLight('#fff9e7','#779883',.85));
  const key=new T.DirectionalLight('#fff0d5',1.8);key.position.set(-3,6,4);key.castShadow=true;
  key.shadow.mapSize.set(2048,2048);key.shadow.camera.left=-3;key.shadow.camera.right=3;key.shadow.camera.top=4;key.shadow.camera.bottom=-3;
  key.shadow.normalBias=.025;key.shadow.bias=-.00012;key.shadow.radius=3;scene.add(key);
  const rim=new T.DirectionalLight('#d7eddf',1.4);rim.position.set(3,3,-3);scene.add(rim);
  const floor=new T.Mesh(new T.PlaneGeometry(200,200),new T.MeshStandardMaterial({color:'#dce4d6',roughness:1}));
  floor.rotation.x=-Math.PI/2;floor.position.y=-.15;floor.receiveShadow=true;scene.add(floor);
  const stage=new T.Mesh(new T.CylinderGeometry(1.32,1.36,.13,96),new T.MeshStandardMaterial({color:'#edf0e6',roughness:.94}));
  stage.position.y=-.085;stage.receiveShadow=true;scene.add(stage);
  const ring=new T.Mesh(new T.TorusGeometry(1.25,.005,4,100),new T.MeshBasicMaterial({color:'#b9c9b2'}));
  ring.rotation.x=-Math.PI/2;ring.position.y=-.014;scene.add(ring);
  const markerMat=new T.MeshBasicMaterial({color:'#c2cdb8'});
  for(let i=0;i<32;i++){
    const a=i/32*Math.PI*2,m=new T.Mesh(new T.BoxGeometry(i%8===0?.014:.008,.002,i%8===0?.07:.025),markerMat);
    m.position.set(Math.sin(a)*1.20,-.012,Math.cos(a)*1.20);m.rotation.y=a;scene.add(m);
  }
  const bench=new T.Group();scene.add(bench);bench.visible=false;
  const benchMat=new T.MeshStandardMaterial({color:'#b2bca3',roughness:.9});
  const seat=new T.Mesh(new T.BoxGeometry(.77,.07,.42),benchMat);seat.position.set(0,.315,-.10);seat.castShadow=true;seat.receiveShadow=true;bench.add(seat);
  [-.27,.27].forEach(x=>{const leg=new T.Mesh(new T.BoxGeometry(.07,.32,.29),benchMat);leg.position.set(x,.13,-.10);leg.castShadow=true;bench.add(leg);});
  let rebuildPending=0;
  function rebuild(){
    const saved=motion?{time:motion.time,phase:motion.phase,speed:motion.speed,actionTime:motion.actionTime,weights:{...motion.weights}}:null;
    if(avatar)avatar.dispose();avatar=C.createAvatar(T,config);scene.add(avatar.root);
    const Controller=motionVersion==='baseline'?window.DawnCharacterV01.MotionController:C.MotionController;
    motion=new Controller(avatar);motion.setAction(action);motion.reducedMotion=$('calm').checked;
    if(saved){Object.assign(motion,saved);if(motion.clocks)motion.clocks[action]=saved.actionTime;}
    avatar.root.traverse(o=>{if(o.isMesh)o.material.wireframe=wireframe;});
    // Kept only for numeric diagnostics and export; no website or user state is read.
    window.characterStudio={avatar,motion,scene,renderer,camera};
  }
  function scheduleRebuild(){clearTimeout(rebuildPending);rebuildPending=setTimeout(rebuild,90);}
  function setAction(name){
    action=name;motion.setAction(name);if(name==='sit')bench.visible=true;
    $('actions').querySelectorAll('button').forEach(b=>{b.classList.toggle('selected',b.dataset.action===name);b.setAttribute('aria-pressed',String(b.dataset.action===name));});
    $('action-label').textContent=actionNames[name][1]+' · '+actionNames[name][2];
  }
  Object.keys(actionNames).forEach(name=>{
    const b=document.createElement('button');b.dataset.action=name;b.setAttribute('aria-pressed',String(name==='idle'));
    b.innerHTML='<span class="action-icon" aria-hidden="true">'+actionNames[name][0]+'</span><span>'+actionNames[name][1]+'</span>';
    if(name==='idle')b.classList.add('selected');b.addEventListener('click',()=>{stopSequence();setAction(name);});$('actions').appendChild(b);
  });
  function syncColors(){
    $('hair-color').value=config.hair;$('eye-color').value=config.eyes;$('jacket-color').value=config.jacket;$('skin-color').value=config.skin;
  }
  palettes.forEach((p,i)=>{
    const b=document.createElement('button');b.classList.toggle('selected',i===0);b.setAttribute('aria-pressed',String(i===0));
    b.innerHTML='<span class="swatches"><i style="background:'+p.jacket+'"></i><i style="background:'+p.hair+'"></i><i style="background:'+p.shirt+'"></i></span>'+p.name;
    b.addEventListener('click',()=>{
      const {name,...colors}=p;Object.assign(config,colors);syncColors();rebuild();
      $('presets').querySelectorAll('button').forEach(x=>{x.classList.toggle('selected',x===b);x.setAttribute('aria-pressed',String(x===b));});
    });$('presets').appendChild(b);
  });
  ['hair','eye','jacket','skin'].forEach(id=>$(id+'-color').addEventListener('input',event=>{
    config[id==='eye'?'eyes':id]=event.target.value;scheduleRebuild();
    $('presets').querySelectorAll('button').forEach(x=>{x.classList.remove('selected');x.setAttribute('aria-pressed','false');});
  }));
  $('hairstyle').addEventListener('click',event=>{
    const b=event.target.closest('[data-hair]');if(!b)return;config.hairStyle=b.dataset.hair;
    $('hairstyle').querySelectorAll('button').forEach(x=>{x.classList.toggle('selected',x===b);x.setAttribute('aria-pressed',String(x===b));});rebuild();
  });
  $('head-scale').addEventListener('input',e=>{config.headScale=Number(e.target.value);$('head-label').textContent=Math.round(config.headScale*100)+'%';scheduleRebuild();});
  $('height').addEventListener('input',e=>{config.height=Number(e.target.value);$('height-label').textContent=Math.round(config.height*100)+'%';scheduleRebuild();});
  $('backpack').addEventListener('change',e=>{config.backpack=e.target.checked;avatar.pivots.backpack.visible=config.backpack;});
  $('wireframe').addEventListener('change',e=>{wireframe=e.target.checked;avatar.root.traverse(o=>{if(o.isMesh)o.material.wireframe=wireframe;});});
  $('calm').checked=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  $('calm').addEventListener('change',e=>motion.reducedMotion=e.target.checked);
  $('pause').addEventListener('click',()=>{paused=!paused;$('pause').textContent=paused?'▷ 播放':'Ⅱ 暫停';$('pause').setAttribute('aria-pressed',String(paused));});
  $('speed').addEventListener('input',e=>{rate=Number(e.target.value);$('speed-label').textContent=rate.toFixed(1)+'×';});
  $('rotate').addEventListener('change',e=>autoRotate=e.target.checked);
  function stopSequence(){sequenceOn=false;$('sequence').setAttribute('aria-pressed','false');$('sequence').textContent='▷ 連續轉場';}
  $('sequence').addEventListener('click',()=>{
    if(sequenceOn){stopSequence();return;}
    sequenceOn=true;sequenceTime=0;sequenceIndex=0;setAction(sequence[0][0]);
    $('sequence').setAttribute('aria-pressed','true');$('sequence').textContent='■ 停止轉場';
  });
  $('motion-version').addEventListener('click',e=>{
    const b=e.target.closest('[data-version]');if(!b||b.dataset.version===motionVersion)return;
    motionVersion=b.dataset.version;motion=null;rebuild();
    $('motion-version').querySelectorAll('button').forEach(x=>{const on=x===b;x.classList.toggle('selected',on);x.setAttribute('aria-pressed',String(on));});
    toast(motionVersion==='baseline'?'正在對照第一版動作':'已切換至優化版動作');
  });
  const view=(y,p=.11,d=4.8)=>{targetYaw=y;targetPitch=p;targetDistance=d;};
  $('view-front').addEventListener('click',()=>view(0));$('view-side').addEventListener('click',()=>view(Math.PI/2));
  $('view-back').addEventListener('click',()=>view(Math.PI));$('view-reset').addEventListener('click',()=>view(.48));
  const pointers=new Map();let pinch=0;
  const canvas=$('scene');
  canvas.addEventListener('pointerdown',e=>{canvas.setPointerCapture(e.pointerId);pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});pinch=0;});
  canvas.addEventListener('pointermove',e=>{
    if(!pointers.has(e.pointerId))return;
    const previous=pointers.get(e.pointerId);pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
    if(pointers.size===2){const a=[...pointers.values()],d=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y);if(pinch)targetDistance=Math.max(2.6,Math.min(7,targetDistance*pinch/d));pinch=d;}
    else {targetYaw-=(e.clientX-previous.x)*.008;targetPitch=Math.max(-.30,Math.min(.8,targetPitch+(e.clientY-previous.y)*.005));}
  });
  ['pointerup','pointercancel','lostpointercapture'].forEach(name=>canvas.addEventListener(name,e=>{pointers.delete(e.pointerId);pinch=0;}));
  canvas.addEventListener('wheel',e=>{e.preventDefault();targetDistance=Math.max(2.6,Math.min(7,targetDistance+e.deltaY*.003));},{passive:false});
  canvas.addEventListener('keydown',e=>{
    if(e.key==='ArrowLeft')targetYaw-=.15;else if(e.key==='ArrowRight')targetYaw+=.15;
    else if(e.key==='ArrowUp')targetPitch=Math.min(.8,targetPitch+.1);else if(e.key==='ArrowDown')targetPitch=Math.max(-.3,targetPitch-.1);
    else if(e.key==='+'||e.key==='=')targetDistance=Math.max(2.6,targetDistance-.2);else if(e.key==='-')targetDistance=Math.min(7,targetDistance+.2);else return;e.preventDefault();
  });
  function toast(text){$('status').textContent=text;$('status').classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('status').classList.remove('show'),2800);}
  function download(filename,bytes,type){const url=URL.createObjectURL(new Blob([bytes],{type}));const a=document.createElement('a');a.href=url;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);}
  $('save-look').addEventListener('click',()=>{download('dawn-explorer-look.json',JSON.stringify({version:1,config},null,2),'application/json');toast('已下載造型設定。');});
  const snapshotButton=document.createElement('button');snapshotButton.className='secondary';snapshotButton.id='save-preview';
  snapshotButton.textContent='下載預覽圖 ↓ PNG';$('save-model').after(snapshotButton);
  snapshotButton.addEventListener('click',()=>{
    renderer.render(scene,camera);
    canvas.toBlob(blob=>{if(blob){download('dawn-animation-v02-preview.png',blob,'image/png');toast('已下載目前姿勢的預覽圖。');}else toast('預覽圖匯出失敗，請再試一次。');},'image/png');
  });
  $('save-model').addEventListener('click',()=>{
    try{const neutral=C.createAvatar(T,config);const clips=window.DawnGLB.bakeClips(neutral,C.MotionController,C.ACTIONS);const bytes=window.DawnGLB.exportGLB(neutral.root,clips);neutral.dispose();download('dawn-explorer-v02.glb',bytes,'model/gltf-binary');toast('已匯出模型與 7 組優化動作。');}
    catch(error){toast('匯出失敗：'+error.message);}
  });
  $('reset-look').addEventListener('click',()=>{
    config={...C.DEFAULTS};syncColors();$('head-scale').value='1';$('height').value='1';$('head-label').textContent='標準';$('height-label').textContent='100%';$('backpack').checked=true;
    $('hairstyle').querySelectorAll('button').forEach(b=>{const on=b.dataset.hair==='bob';b.classList.toggle('selected',on);b.setAttribute('aria-pressed',String(on));});
    $('presets').querySelectorAll('button').forEach((b,i)=>{b.classList.toggle('selected',i===0);b.setAttribute('aria-pressed',String(i===0));});rebuild();toast('已恢復第一版造型。');
  });
  const resize=()=>{const r=$('viewport').getBoundingClientRect();renderer.setSize(r.width,r.height,false);camera.aspect=r.width/r.height;camera.updateProjectionMatrix();};
  new ResizeObserver(resize).observe($('viewport'));
  rebuild();resize();let previous=performance.now(),frameCount=0;
  function frame(now){
    requestAnimationFrame(frame);const dt=Math.max(0,Math.min((now-previous)/1000,.1));previous=now;
    if(document.hidden)return;
    if(!paused){
      if(sequenceOn){sequenceTime+=dt*rate;if(sequenceTime>=sequence[sequenceIndex][1]){sequenceTime=0;sequenceIndex=(sequenceIndex+1)%sequence.length;setAction(sequence[sequenceIndex][0]);}}
      motion.update(dt*rate);
    }
    bench.visible=action==='sit'||(motion.weights.sit||0)>.03;
    if(autoRotate)targetYaw+=dt*.24;
    // Shortest-path camera interpolation, also stable across frame rates.
    let diff=targetYaw-yaw;diff=Math.atan2(Math.sin(diff),Math.cos(diff));yaw+=diff*(1-Math.exp(-9*dt));
    pitch+=(targetPitch-pitch)*(1-Math.exp(-9*dt));distance+=(targetDistance-distance)*(1-Math.exp(-9*dt));
    camera.position.set(Math.sin(yaw)*Math.cos(pitch)*distance,1.12+Math.sin(pitch)*distance,Math.cos(yaw)*Math.cos(pitch)*distance);
    camera.lookAt(0,1.12,0);renderer.render(scene,camera);
    if(frameCount++%45===0)$('render-stats').textContent=(renderer.info.render.triangles/1000).toFixed(1)+'k 三角形 · '+renderer.info.render.calls+' draw calls';
  }
  requestAnimationFrame(frame);
})();
