const {test}=require('node:test');
const assert=require('node:assert/strict');
const THREE=require('../vendor/three.r128.min.cjs');
const C=require('../src/character.js');
const G=require('../src/glb-export.js');
const Baseline=require('../src/character-v01.js');

test('two-bone IK reaches reachable targets and keeps the boot level',()=>{
  for(const [y,z] of [[-.625,0],[-.57,.22],[-.55,-.30],[-.42,.15]]){
    const p=C.solveLeg(y,z);
    const actualY=-.34*Math.cos(p.hip)-.32*Math.cos(p.hip+p.knee);
    const actualZ=-.34*Math.sin(p.hip)-.32*Math.sin(p.hip+p.knee);
    assert.ok(Math.abs(actualY-y)<1e-6);assert.ok(Math.abs(actualZ-z)<1e-6);
    assert.ok(Math.abs(p.hip+p.knee+p.ankle)<1e-8);
  }
});
function ankleY(avatar,side){return avatar.pivots['ankle'+side].getWorldPosition(new THREE.Vector3()).y;}
test('stopping at a swing phase returns both feet to the same ground height',()=>{
  const a=C.createAvatar(THREE),b=C.createAvatar(THREE),before=new Baseline.MotionController(a),after=new C.MotionController(b);
  before.phase=after.phase=Math.PI*1.6;before.update(1/60);after.update(1/60);
  const oldDifference=Math.abs(ankleY(a,'L')-ankleY(a,'R')),newDifference=Math.abs(ankleY(b,'L')-ankleY(b,'R'));
  assert.ok(oldDifference>.05,'The baseline should reproduce the lifted-foot bug');
  assert.ok(newDifference<.0001,'Idle feet should settle together, independently of stopped phase');
  a.dispose();b.dispose();
});
test('a constant-speed support foot cancels forward root travel',()=>{
  const phase=.2*Math.PI*2,stride=.44,duty=.62,speed=.65,dt=.001;
  const a=C.sampleGaitFoot(phase,stride,duty,.1),b=C.sampleGaitFoot(phase+speed*dt*duty/stride*Math.PI*2,stride,duty,.1);
  assert.equal(a.contact,true);assert.equal(b.contact,true);
  assert.ok(Math.abs((b.z-a.z)+speed*dt)<1e-8);
});
test('quick action changes keep the outgoing jump clock and do not teleport the hips',()=>{
  const a=C.createAvatar(THREE),m=new C.MotionController(a);m.setAction('jump');
  for(let i=0;i<50;i++)m.update(1/120);
  const clock=m.clocks.jump,y=a.pivots.hips.position.y;
  m.setAction('wave');m.update(1/120);
  assert.ok(m.clocks.jump>clock,'Outgoing action time must keep advancing');
  assert.ok(Math.abs(a.pivots.hips.position.y-y)<.015,'First transition frame must stay close to the displayed pose');
  a.dispose();
});
test('sole corners remain above the flat ground through jump, sit and rapid transitions',()=>{
  const a=C.createAvatar(THREE),m=new C.MotionController(a);
  for(const action of ['walk','run','jump','sit','wave','attack','idle']){
    m.setAction(action);
    for(let i=0;i<150;i++){
      m.update(1/60);
      for(const {mesh,points} of m.soles)for(const point of points){
        const y=point.clone().applyMatrix4(mesh.matrixWorld).y;assert.ok(y>-.00001,action+' sole is below ground: '+y);
      }
    }
  }
  a.dispose();
});
test('all actions and hairstyle variants retain finite transforms after transitions and long frames',()=>{
  for(const hairStyle of ['bob','long','pony']){
    const avatar=C.createAvatar(THREE,{hairStyle});const m=new C.MotionController(avatar);
    for(const action of C.ACTIONS){
      m.setAction(action);
      for(let frame=0;frame<100;frame++)m.update(frame===40?2:1/60);
      avatar.root.traverse(o=>{for(const n of [...o.position.toArray(),...o.quaternion.toArray(),...o.scale.toArray()])assert.ok(Number.isFinite(n),o.name+' has a non-finite transform');});
    }
    avatar.dispose();
  }
});
test('30 and 120 fps locomotion converge to the same phase and joints',()=>{
  const a=C.createAvatar(THREE),b=C.createAvatar(THREE),ma=new C.MotionController(a),mb=new C.MotionController(b);
  ma.setAction('run');mb.setAction('run');for(let i=0;i<120;i++)ma.update(1/30);for(let i=0;i<480;i++)mb.update(1/120);
  assert.ok(Math.abs(ma.speed-mb.speed)<1e-6);
  assert.ok(Math.abs(Math.atan2(Math.sin(ma.phase-mb.phase),Math.cos(ma.phase-mb.phase)))<.07);
  assert.ok(Math.abs(a.pivots.shinL.rotation.x-b.pivots.shinL.rotation.x)<.08);
  a.dispose();b.dispose();
});
test('exported GLB has valid chunk bounds, hierarchy, materials and seven closed animation cycles',()=>{
  const avatar=C.createAvatar(THREE);const clips=G.bakeClips(avatar,C.MotionController,C.ACTIONS);
  const bytes=G.exportGLB(avatar.root,clips),v=new DataView(bytes);
  assert.equal(v.getUint32(0,true),0x46546c67);assert.equal(v.getUint32(8,true),bytes.byteLength);
  const jlen=v.getUint32(12,true),json=JSON.parse(new TextDecoder().decode(new Uint8Array(bytes,20,jlen)));
  assert.equal(json.animations.length,7);assert.ok(json.meshes.length>40);
  const offset=20+jlen;assert.equal(v.getUint32(offset+4,true),0x004e4942);
  assert.ok(json.bufferViews.every(b=>b.byteOffset%4===0&&b.byteOffset+b.byteLength<=json.buffers[0].byteLength));
  for(const anim of json.animations){assert.ok(anim.channels.length>30);for(const ch of anim.channels)assert.ok(ch.target.node<json.nodes.length);}
  for(const clip of clips)for(const track of clip.tracks){
    const w=track.path==='rotation'?4:3;for(let i=0;i<w;i++)assert.ok(Math.abs(track.values[i]-track.values[track.values.length-w+i])<1e-5);
  }
  avatar.dispose();
});
