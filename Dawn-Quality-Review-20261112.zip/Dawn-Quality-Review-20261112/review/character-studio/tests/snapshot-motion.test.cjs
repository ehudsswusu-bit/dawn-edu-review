const {test}=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm');
const THREE=require('../vendor/three.r128.min.cjs');
const {candidate,base}=require('../tools/snapshot-motion-review.cjs');
function getPose(source){return source.match(/function poseBlTick\(t, P\)\{[\s\S]*?\n\}/)[0];}
function rig(){const p={};['shoulderL','shoulderR','elbowL','elbowR','thighL','thighR','shinL','shinR'].forEach(n=>{p[n]=new THREE.Object3D();p[n].rotation.x=.42;});return p;}
test('swim blending preserves the incoming pose as its weight tends to zero',()=>{
  const ctx={POSE:{mode:null},SWIM:{poseK:.0101}};vm.createContext(ctx);vm.runInContext(getPose(candidate(base)),ctx);
  const p=rig();ctx.poseBlTick(.4,p);assert.ok(Math.abs(p.shoulderL.rotation.x-.42)<.03);
});
test('the swimming pose animates opposite legs and propagates through the BL pivot set',()=>{
  const ctx={POSE:{mode:null},SWIM:{poseK:1}};vm.createContext(ctx);vm.runInContext(getPose(candidate(base)),ctx);
  const p=rig();ctx.poseBlTick(.4,p);assert.ok(Math.abs(p.thighL.rotation.x+p.thighR.rotation.x)<1e-6);
  assert.ok(Math.abs(p.shinL.rotation.x-p.shinR.rotation.x)>.1);
});
test('variable stride does not retroactively jump accumulated gait phase',()=>{
  const oldDistance=100,oldStride=1,newStride=1.2,delta=.02;
  const oldPhase=oldDistance/(oldStride*2)*Math.PI*2;
  const legacy=(oldDistance+delta)/(newStride*2)*Math.PI*2;
  const fixed=(oldPhase+delta/(newStride*2)*Math.PI*2)%(Math.PI*2);
  const circular=x=>Math.abs(Math.atan2(Math.sin(x),Math.cos(x)));
  assert.ok(circular(legacy-oldPhase)>1);assert.ok(circular(fixed-oldPhase)<.06);
});
test('snapshot patch anchors are unique and all inline scripts remain syntactically valid',()=>{
  const changed=candidate(base);assert.notEqual(changed,base);
  let count=0;for(const match of changed.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)){
    if(/\bsrc\s*=|type\s*=\s*["']module/.test(match[1])||!match[2].trim())continue;
    new vm.Script(match[2]);count++;
  }
  assert.ok(count>=3);
});
