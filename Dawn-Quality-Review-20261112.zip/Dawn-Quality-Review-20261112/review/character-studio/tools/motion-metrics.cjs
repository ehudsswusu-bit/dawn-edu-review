const fs=require('node:fs'),path=require('node:path');
const THREE=require('../vendor/three.r128.min.cjs');
const C=require('../src/character.js'),B=require('../src/character-v01.js');
function measure(Controller){
  const avatar=C.createAvatar(THREE),m=new Controller(avatar);
  m.phase=Math.PI*1.6;m.update(1/60);
  const a=avatar.pivots.ankleL.getWorldPosition(new THREE.Vector3()),b=avatar.pivots.ankleR.getWorldPosition(new THREE.Vector3());
  const stoppedAnkleHeightDifference=Math.abs(a.y-b.y);
  m.reset();m.setAction('jump');for(let i=0;i<50;i++)m.update(1/120);
  const y=avatar.pivots.hips.position.y;m.setAction('wave');m.update(1/120);
  const transitionHipDisplacement=Math.abs(avatar.pivots.hips.position.y-y);
  avatar.dispose();return {stoppedAnkleHeightDifference,transitionHipDisplacement};
}
const report={units:'model units; dt = 1/120 s for jump-to-wave transition',baseline:measure(B.MotionController),optimized:measure(C.MotionController)};
fs.writeFileSync(path.resolve(__dirname,'../review/motion-metrics.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
