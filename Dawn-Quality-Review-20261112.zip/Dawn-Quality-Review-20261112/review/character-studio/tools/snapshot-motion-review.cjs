// Produces a reviewable patch; never modifies the reference snapshot or deploys anything.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const os=require('node:os'),cp=require('node:child_process');
const source=path.resolve(__dirname,'../../snapshot-base-island.html');
const base=fs.readFileSync(source,'utf8').replace(/\r\n/g,'\n');
function once(text,before,after){
  if(!text.includes(before)||text.indexOf(before)!==text.lastIndexOf(before))throw new Error('Patch anchor is missing or ambiguous');
  return text.replace(before,after);
}
function candidate(original){
  let result=once(original,
    '    player.distAcc = (player.distAcc || 0) + spdNow * rawDt;\n    player.strideLen = .72 + Math.min(1.6, spdNow / 6) * .38;\n    player.stepPhase = player.distAcc / (player.strideLen * 2) * Math.PI * 2;',
    '    /* MOTION02: incremental resolved-distance phase; changing stride must not rescale history. */\n    var _gaitDist = isFinite(movedNow) && movedNow <= Math.max(1, spdNow * rawDt * 3) ? movedNow : 0;\n    player.distAcc = (player.distAcc || 0) + _gaitDist;\n    player.strideLen = .72 + Math.min(1.6, spdNow / 6) * .38;\n    player.stepPhase = ((player.stepPhase || 0) + _gaitDist / (player.strideLen * 2) * Math.PI * 2) % (Math.PI * 2);');
  const start=result.indexOf('function blCharTick(rawDt, t){'),end=result.indexOf('\n/* ---- 寵物樞軸',start);
  if(start<0||end<0)throw new Error('BL animation function boundaries were not found');
  let body=result.slice(start,end);
  body=once(body,
`  if (!player.grounded){
    if (P.thighL){ P.thighL.rotation.x = -.5; P.thighR.rotation.x = .35; }
    if (P.shoulderL){ P.shoulderL.rotation.x = -.7; P.shoulderR.rotation.x = -.7; }
    if (P.shinL){ P.shinL.rotation.x = .55; P.shinR.rotation.x = .9; }
    if (P.elbowL){ P.elbowL.rotation.x = -.7; P.elbowR.rotation.x = -.7; }
  }`,
`  /* MOTION02: smooth airborne entry/exit; swimming owns its own full-body pose below. */
  var _airWant = !player.grounded && !POSE.mode && !(typeof SWIM !== 'undefined' && SWIM && SWIM.on) ? 1 : 0;
  BL.airK = (BL.airK || 0) + (_airWant - (BL.airK || 0)) * (1 - Math.exp(-12 * Math.min(rawDt, .05)));
  if (BL.airK > .001){
    var _airMix = function(cur, target){ return cur + (target - cur) * BL.airK; };
    if (P.thighL){ P.thighL.rotation.x = _airMix(P.thighL.rotation.x, -.5); P.thighR.rotation.x = _airMix(P.thighR.rotation.x, .35); }
    if (P.shoulderL){ P.shoulderL.rotation.x = _airMix(P.shoulderL.rotation.x, -.7); P.shoulderR.rotation.x = _airMix(P.shoulderR.rotation.x, -.7); }
    if (P.shinL){ P.shinL.rotation.x = _airMix(P.shinL.rotation.x, .55); P.shinR.rotation.x = _airMix(P.shinR.rotation.x, .9); }
    if (P.elbowL){ P.elbowL.rotation.x = _airMix(P.elbowL.rotation.x, -.7); P.elbowR.rotation.x = _airMix(P.elbowR.rotation.x, -.7); }
  }`);
  result=result.slice(0,start)+body+result.slice(end);
  result=once(result,
`    if (P.shoulderL) P.shoulderL.rotation.x = (-1.5 + spad * 1.2) * sk;
    if (P.shoulderR) P.shoulderR.rotation.x = (-1.5 + spad2 * 1.2) * sk;
    if (P.elbowL) P.elbowL.rotation.x = (-.55 + Math.max(0, -spad) * .5) * sk;
    if (P.elbowR) P.elbowR.rotation.x = (-.55 + Math.max(0, -spad2) * .5) * sk;`,
`    /* MOTION02: blend from the current gait, then animate legs too; CW inherits these pivots. */
    var swimMix = function(cur, target){ return cur + (target - cur) * sk; };
    if (P.shoulderL) P.shoulderL.rotation.x = swimMix(P.shoulderL.rotation.x, -1.5 + spad * 1.2);
    if (P.shoulderR) P.shoulderR.rotation.x = swimMix(P.shoulderR.rotation.x, -1.5 + spad2 * 1.2);
    if (P.elbowL) P.elbowL.rotation.x = swimMix(P.elbowL.rotation.x, -.55 + Math.max(0, -spad) * .5);
    if (P.elbowR) P.elbowR.rotation.x = swimMix(P.elbowR.rotation.x, -.55 + Math.max(0, -spad2) * .5);
    if (P.thighL) P.thighL.rotation.x = swimMix(P.thighL.rotation.x, spad * .38);
    if (P.thighR) P.thighR.rotation.x = swimMix(P.thighR.rotation.x, spad2 * .38);
    if (P.shinL) P.shinL.rotation.x = swimMix(P.shinL.rotation.x, .25 + Math.max(0, spad2) * .3);
    if (P.shinR) P.shinR.rotation.x = swimMix(P.shinR.rotation.x, .25 + Math.max(0, spad) * .3);`);
  return result;
}
function build(){
  const modified=candidate(base),dir=path.resolve(__dirname,'../review');fs.mkdirSync(dir,{recursive:true});
  const temp=fs.mkdtempSync(path.join(os.tmpdir(),'dawn-motion-review-'));
  const a=path.join(temp,'before.html'),b=path.join(temp,'after.html');fs.writeFileSync(a,base);fs.writeFileSync(b,modified);
  const diff=cp.spawnSync('git',['diff','--no-index','--',a,b],{encoding:'utf8',maxBuffer:6e6});
  if(diff.status!==1)throw new Error(diff.stderr||'Expected a nonempty Git diff');
  const lines=diff.stdout.split('\n');lines[0]='diff --git a/pages/island-survival.html b/pages/island-survival.html';
  const minus=lines.findIndex(x=>x.startsWith('--- ')),plus=lines.findIndex(x=>x.startsWith('+++ '));
  lines[minus]='--- a/pages/island-survival.html';lines[plus]='+++ b/pages/island-survival.html';
  fs.writeFileSync(path.join(dir,'snapshot-animation-v02.patch'),lines.join('\n'));
  fs.writeFileSync(path.join(dir,'snapshot-base.json'),JSON.stringify({release:'snapshot-2026-11-11',source:'pages/island-survival.html',normalizedSourceSHA256:crypto.createHash('sha256').update(base).digest('hex'),candidateSHA256:crypto.createHash('sha256').update(modified).digest('hex'),scope:['incremental gait phase','BL airborne blending','BL/CW swimming legs'],deployed:false},null,2));
  fs.unlinkSync(a);fs.unlinkSync(b);fs.rmdirSync(temp);
  console.log('Created review/snapshot-animation-v02.patch; reference files are unchanged.');
}
if(require.main===module)build();
module.exports={candidate,base};
