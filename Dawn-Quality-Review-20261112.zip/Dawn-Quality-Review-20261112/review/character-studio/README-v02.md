# 曙光角色工作室 · 動畫優化版 v0.2

獨立的角色與動作預覽專案。保留第一版動畫作對照，尚未整合進正式網站，也沒有上傳儲存庫或部署。

## 開啟

解壓縮交付包，直接用 Chrome／Edge 開啟 `Dawn-Character-Studio-v02.html`。程式與 Three.js 已內嵌，不需要安裝、登入或連網。瀏覽器須支援 WebGL。

在開發資料夾也可執行 `npm start` 或 `node tools/serve.cjs`，開啟 http://127.0.0.1:4173 。不需要 npm install。

## 如何看前後差異

1. 點「走路」或「跑步」，再切換「待機」：比較停步後雙腳是否落地。
2. 點「跳躍」，騰空時切換「招手」或「坐下」：比較身體是否突然跳位。
3. 在「第一版／優化版」間切換；兩者使用相同模型與鏡頭，僅改變動畫控制器。
4. 點「連續轉場」，自動展示待機、走路、跑步、停步、跳躍、招手、坐下與揮擊。
5. 可降低播放速度、暫停，或下載目前姿勢的 PNG。

## 本輪完成

- 支撐腳的位移與前進速度一致，擺腿兩端速度銜接；停步時抬腳量也會歸零。
- 各動作有獨立時鐘；快速切換不再重設正在淡出的跳躍／揮擊。
- 從當前畫面姿勢擷取轉場起點，以四元數處理旋轉、平滑混合位移。
- 完整姿勢計算後檢查鞋底角點，修正平地穿透。
- 保留 7 組動作、3 種髮型、配色與比例調整、GLB／JSON 匯出。
- 視覺檢查修正頭髮面片繞序、色彩空間與過強燈光；修正瀏覽器首幀可能出現的負時間差。

## 交付檔

- `Dawn-Character-Studio-v02.html`：獨立預覽，含模型、前後兩版動畫及匯出程式。
- `dawn-explorer-v02.glb`：模型與 7 組優化動作，約 1.50 MiB。
- `dawn-explorer-look.json`：造型參數。
- `animation-v02-preview.png`：瀏覽器實際匯出的招手姿勢。
- `ANIMATION-REVIEW.md`：快照分析、優化範圍與整合限制。
- `snapshot-animation-v02.patch`：供朋友審查的島嶼動畫修補檔。
- `snapshot-base.json`：修補基線與候選版本雜湊。
- `motion-metrics.json`：第一版／優化版的可重現數值比較。
- `LICENSE-three.txt`：Three.js r128 MIT 授權。

## 驗證與限制

12 項測試通過：IK、停步腳高差、支撐腳位移、快速轉場、鞋底穿透、動作切換穩定、30/120 FPS 一致性、GLB 結構與循環，以及快照修補的游泳、步態與腳本語法。

本機瀏覽器已實際開啟預覽，確認行走、跑步、坐下、招手及版本切換，並匯出 PNG；本輪修正後的操作沒有新增 error 日誌。

快照 patch 尚未在完整島嶼玩法內實測，須由朋友於測試環境審查、驗收後再決定部署。原始快照與正式站均未修改。

模型仍採剛性關節節點，尚非完整連續蒙皮；腳底修正只處理水平預覽地面，未實作斜坡、多層地形碰撞或任意座椅配準。揮擊是空手動作研究，GLB 不包含座椅或命中邏輯。GLB 匯出會在循環尾端做短暫接點混合，與即時控制器並非逐幀完全相同。

## 開發指令

```text
npm test
npm run export
node tools/motion-metrics.cjs
node tools/snapshot-motion-review.cjs
node tools/build-portable.cjs
```

`tools/snapshot-motion-review.cjs` 僅讀取指定快照，產生審查用 patch，不寫回快照。第一版交付檔保留於 `delivery/`，第二版位於 `delivery-v02/`。
