/* 平台導引彈窗：可略過的首次介紹，
   之後可從「家」的快捷入口重新打開 */

const GUIDE_PAGES = [
  {
    title: "歡迎來到曙光學習",
    body: `
      <p>嗨，我是你的<b>靈獸</b>，你的學習陪伴者！</p>
      <p>這裡跟其他學習 App 不一樣：我不會直接丟答案給你，而是陪你走完一整個學習循環——從好奇，到想通，到真正記住。</p>
      <p>我住在<b>靈獸頁</b>，去那裡可以跟我聊天、調整我的性格、設定我怎麼叫你（預設就是你的用戶名稱，也可以自訂）。主控台的對話框、圓圈上的靈獸按鈕，都是同一個我。</p>
      <p style="color:var(--paper-400);font-size:13px;">花一分鐘認識這裡，也可以先略過，之後再從系統導引開啟。</p>`,
  },
  {
    title: "認識四個地方",
    body: `
      <p><b>曙光寶庫</b>——你的知識老家。課本的、文化的、好玩的，什麼都可以收藏。以後的學習都從這裡出發。</p>
      <p><b>情境學習</b>——化身成某個角色，親身經歷一個概念。比如當唐朝農民學租庸調，用身體記住知識。</p>
      <p><b>思辨對話</b>——跟我把一個想法聊到想通，不直接給答案；<b>知識對戰＋複習</b>——AI 出題考你，答錯會告訴你卡在哪個迷思，再用間隔重複，在你快忘記時提醒複習。</p>
      <p><b>學習排程＋書架</b>——把空檔排成學習計畫、把喜歡的庫收進書架；學累了就去<b>群島、遊戲測驗</b>玩一下，玩著玩著就複習了。</p>`,
  },
  {
    title: "獨家導覽：圓盤怎麼用",
    body: `
      <p>曙光學習沒有傳統選單列，用的是一顆<b>圓盤導覽</b>，平時只看到圖示，滑鼠靠近哪一格，那格的名字才會出現膠囊，不會一次全亮很亂。</p>
      <p><b>第一層有五格</b>：樂趣、內容、功能、設定、家，功能在最上面、內容在左上。點一格會展開<b>第二層</b>，例如點內容，會看到學習排程、學習總覽、跨語言閱讀、曙光寶庫、書架；點功能，會看到思辨對話、情境學習、知識對戰、複習、遊戲測驗，點了就直接去那一頁。</p>
      <p><b>想回去</b>：第二層點中間的「返回」回第一層；第一層點中間的星砂圓圈（下面有房子圖示）回主控台，已經在主控台就捲回頂部。</p>
      <p><b>圓盤上面三顆小鈕</b>：左上是深淺色切換，中間靈獸大頭是跟靈獸對話，右上對話泡是即時通訊。圓盤可以按住空白處拖到順手的位置，位置會記住；萬一拖出畫面，下次會自動回到右下角。</p>
      <p><b>手機版沒有圓盤</b>，改成底部磁吸 dock 加漢堡選單，功能一樣，只是排法不同，不用找圓盤。</p>`,
  },
  {
    title: "靈獸住在哪裡",
    body: `
      <p>我住在<b>靈獸頁</b>，也會在<b>主控台</b>陪你。你隨時可以直接跟我說話：問我問題、讓我推薦今天學什麼、幫你安排這週的學習計畫。我還會主動提醒你該複習的東西。</p>
      <p>靈獸頁除了聊天，還可以餵食、陪玩、改名、調整我的性格、設定我怎麼叫你。性格一改，主控台跟懸浮對話的語氣都會跟著變。</p>
      <p>對了，每一頁的最下面都有<b>學習歷程</b>——點開可以看到當時的完整紀錄、回到當時的進度。同一個主題的各種學習會自動整理在一起。</p>`,
  },
  {
    title: "選用功能",
    body: `
      <p>有些功能不是每個人都需要，預設是關的，你隨時可以在<b>設定</b>裡開關：</p>
      <label style="display:flex;gap:10px;align-items:flex-start;cursor:pointer;background:var(--wash-04);border:1px solid var(--wash-10);border-radius:12px;padding:12px;margin-top:8px;">
        <input type="checkbox" id="guide-classroom" style="width:18px;height:18px;accent-color:var(--brass-400);margin-top:2px;flex:none;">
        <span><b>Google Classroom 整合</b><br>
        <span style="font-size:13px;color:var(--paper-400);">在主控台顯示待交作業、同步到學習排程。啟用後到主控台按「連結 Classroom」授權（唯讀，不會動到你的課程資料）。</span></span>
      </label>`,
  },
  {
    title: "準備好了",
    body: `
      <p>導引讀完了！從主控台跟我說話，或去靈獸頁找我聊天：</p>
      <p style="color:var(--paper-400);font-size:13px;">按「我了解了」之後，我會在靈獸頁跟主控台等你，隨時給你下一步的建議。</p>`,
  },
];

/**
 * 顯示平台導引彈窗；可完成導覽，也可略過或按 Escape。
 * @param {object} opts.onDone - 確認讀完後的回呼
 */
export function showPlatformGuide(opts = {}) {
  if (document.getElementById("guide-overlay")) return;
  const previousFocus = document.activeElement;
  let step = 0;
  const total = GUIDE_PAGES.length;

  const overlay = document.createElement("div");
  overlay.id = "guide-overlay";
  overlay.style.cssText = "position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center;background:oklch(0 0 0 / 0.72);backdrop-filter:blur(4px);padding:16px;";
  overlay.innerHTML = `
    <div id="guide-card" role="dialog" aria-modal="true" aria-labelledby="guide-title" tabindex="-1" style="width:100%;max-width:520px;max-height:88vh;overflow-y:auto;background:var(--ink-800);border:1px solid oklch(1 0 0 / 0.12);border-radius:16px;padding:28px 24px;box-shadow:0 24px 64px oklch(0 0 0 / 0.5);">
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;">
        <img src="../assets/icons/nav-pet.webp" alt="靈獸" style="width:48px;height:48px;border-radius:50%;object-fit:cover;">
        <div>
          <div style="font-size:11px;letter-spacing:.15em;color:var(--brass-400);">靈獸的平台導引</div>
          <h2 id="guide-title" style="margin:2px 0 0;font-size:20px;"></h2>
        </div>
      </div>
      <div id="guide-dots" style="display:flex;gap:6px;margin-bottom:16px;"></div>
      <div id="guide-body" style="font-size:14px;line-height:1.9;color:var(--paper-200);"></div>
      <div style="display:flex;gap:8px;justify-content:space-between;margin-top:24px;">
        <button id="guide-prev" class="btn btn-ghost">上一步</button>
        <button id="guide-skip" class="btn btn-ghost">先略過</button>
        <button id="guide-next" class="btn btn-primary">下一步</button>
      </div>
      <div id="guide-hint" role="status" aria-live="polite" style="text-align:center;font-size:11px;color:var(--paper-400);margin-top:12px;"></div>
    </div>`;
  document.body.appendChild(overlay);
  const close = skipped => {
    overlay.remove();
    document.removeEventListener("keydown", onKey, true);
    if (previousFocus && previousFocus.isConnected) previousFocus.focus();
    try { opts.onDone && opts.onDone({ skipped }); } catch {}
  };
  const onKey = e => {
    if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); close(true); return; }
    if (e.key !== "Tab") return;
    const buttons = [...overlay.querySelectorAll('button, input, [href], [tabindex="0"]')]
      .filter(el => !el.disabled && el.getClientRects().length && getComputedStyle(el).visibility !== "hidden");
    const first = buttons[0], last = buttons[buttons.length - 1];
    if (!first) { e.preventDefault(); return; }
    if (e.shiftKey && (document.activeElement === first || !buttons.includes(document.activeElement))) {
      e.preventDefault(); last.focus();
    } else if (!e.shiftKey && (document.activeElement === last || !buttons.includes(document.activeElement))) {
      e.preventDefault(); first.focus();
    }
  };
  document.addEventListener("keydown", onKey, true);

  const render = () => {
    const p = GUIDE_PAGES[step];
    document.getElementById("guide-title").textContent = p.title;
    document.getElementById("guide-body").innerHTML = p.body;
    document.getElementById("guide-dots").innerHTML = GUIDE_PAGES.map((_, i) =>
      `<span style="flex:1;height:4px;border-radius:2px;background:${i <= step ? "var(--brass-300)" : "oklch(1 0 0 / 0.12)"};"></span>`).join("");
    document.getElementById("guide-prev").style.visibility = step === 0 ? "hidden" : "visible";
    const nextBtn = document.getElementById("guide-next");
    nextBtn.textContent = step === total - 1 ? "我了解了，開始探索" : "下一步";
    document.getElementById("guide-hint").textContent =
      step === total - 1 ? "讀完請按「我了解了」" : `第 ${step + 1} 頁，共 ${total} 頁`;
    document.getElementById("guide-card").scrollTop = 0;
    document.getElementById("guide-card").focus();
    /* 選用功能頁的 checkbox 連動 localStorage */
    const crBox = document.getElementById("guide-classroom");
    if (crBox) {
      try { crBox.checked = localStorage.getItem("dawn_feat_classroom") === "1"; } catch {}
      crBox.onchange = () => {
        try { localStorage.setItem("dawn_feat_classroom", crBox.checked ? "1" : "0"); } catch {}
      };
    }
  };

  document.getElementById("guide-prev").onclick = () => {
    if (step > 0) { step--; render(); }
  };
  document.getElementById("guide-skip").onclick = () => close(true);
  document.getElementById("guide-next").onclick = () => {
    if (step < total - 1) { step++; render(); }
    else {
      close(false);
    }
  };
  /* Background clicks keep the guide open; explicit skip and Escape are available. */
  overlay.addEventListener("click", e => {
    if (e.target === overlay) {
      const card = document.getElementById("guide-card");
      card.style.transform = "translateX(0)";
      if (!window.matchMedia?.("(prefers-reduced-motion: reduce)").matches && card.animate) card.animate(
        [{ transform: "translateX(0)" }, { transform: "translateX(-8px)" }, { transform: "translateX(8px)" }, { transform: "translateX(0)" }],
        { duration: 220 }
      );
    }
  });

  render();
}
