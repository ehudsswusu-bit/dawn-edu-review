/* 曙光學習：統一進度快取層（progress.js）
 * classic script、零依賴、不 import 任何東西，給所有頁面共用。
 * 用法：各頁以 classic <script src=".../js/core/progress.js?v=prog001">
 * 在 module script 之前載入，之後用 window.DawnProgress.save/load/remove；
 * 已登入者可用 pushToCloud/pullFromCloud/syncFromCloud 同步到
 * Supabase user_progress 表（跨裝置接續進度）。
 * 原則：本地一律先寫 localStorage（重新整理立即復原），
 * 雲端同步失敗絕不拋錯、絕不影響頁面。
 */
(function () {
  "use strict";
  var PREFIX = "dawn_progress_";

  function nowISO() {
    try { return new Date().toISOString(); }
    catch (e) { return ""; }
  }

  function readRaw(key) {
    try {
      var raw = localStorage.getItem(PREFIX + key);
      if (!raw) return null;
      var obj = JSON.parse(raw);
      if (!obj || typeof obj !== "object") return null;
      return obj;
    } catch (e) { return null; }
  }

  function writeRaw(key, obj) {
    try { localStorage.setItem(PREFIX + key, JSON.stringify(obj)); return true; }
    catch (e) { return false; /* Let callers distinguish a failed save. */ }
  }

  async function pullFromCloud(client, userId, key) {
    try {
      if (!client || !userId || !key) return null;
      var res = await client.from("user_progress")
        .select("data,updated_at").eq("user_id", userId).eq("key", key).maybeSingle();
      if (res.error || !res.data) return null;
      return res.data;
    } catch (e) { return null; }
  }

  window.DawnProgress = {
    /* 本地存檔：值 {v:1, updatedAt: ISO字串, data} */
    save: function (key, data) {
      return writeRaw(key, { v: 1, updatedAt: nowISO(), data: data });
    },
    /* 回 {data, updatedAt} 或 null */
    load: function (key) {
      var obj = readRaw(key);
      if (!obj) return null;
      return { data: obj.data, updatedAt: obj.updatedAt || "" };
    },
    remove: function (key) {
      try { localStorage.removeItem(PREFIX + key); } catch (e) {}
    },
    /* 把本地副本 upsert 到 user_progress（失敗回 false，不拋錯） */
    pushToCloud: async function (client, userId, key) {
      try {
        if (!client || !userId || !key) return false;
        var local = readRaw(key);
        if (!local) return false;
        var res = await client.from("user_progress").upsert({
          user_id: userId, key: key, data: local.data === undefined ? {} : local.data,
          updated_at: local.updatedAt || nowISO(),
        }, { onConflict: "user_id,key" });
        return !res.error;
      } catch (e) { return false; }
    },
    /* 回雲端 row {data, updated_at} 或 null */
    pullFromCloud: pullFromCloud,
    /* 雲端比本地新才覆蓋本地並回雲端 data，否則回 null。
       新舊比較在寫入當下重讀本地，呼叫端不要自己先 pull 再套用，避免競態。 */
    syncFromCloud: async function (client, userId, key) {
      try {
        var row = await pullFromCloud(client, userId, key);
        if (!row) return null;
        var local = readRaw(key);
        var cloudT = row.updated_at || "";
        var localT = (local && local.updatedAt) || "";
        var cloudMs = Date.parse(cloudT), localMs = Date.parse(localT);
        if (!Number.isFinite(cloudMs)) return null;
        if (local && Number.isFinite(localMs) && cloudMs <= localMs) return null;
        if (!writeRaw(key, { v: 1, updatedAt: cloudT, data: row.data })) return null;
        return row.data;
      } catch (e) { return null; }
    },
  };
})();
