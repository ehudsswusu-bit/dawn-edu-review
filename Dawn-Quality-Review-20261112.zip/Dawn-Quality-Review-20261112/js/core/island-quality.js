/* Pure helpers shared by the island and the offline review scene. */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.DawnIslandQuality = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  function advancePhase(phase, distance, stride) {
    if (!Number.isFinite(phase)) phase = 0;
    if (!Number.isFinite(distance) || distance < 0 || !(stride > 0)) return phase;
    return (phase + distance / (stride * 2) * Math.PI * 2) % (Math.PI * 2);
  }
  function damp(current, target, rate, dt) {
    return current + (target - current) * (1 - Math.exp(-rate * Math.max(0, dt)));
  }
  function grassHeight(x, z, height) {
    // Shorter grass near paths makes feet and ground readable; distant tufts stay varied.
    var path = Math.min(Math.abs(x), Math.abs(z));
    return height * (.55 + .28 * Math.min(1, path / 3));
  }
  function stoneGeometry(THREE, radius, seed) {
    var geo = new THREE.IcosahedronGeometry(radius, 2);
    var p = geo.attributes.position, colors = [];
    for (var i = 0; i < p.count; i++) {
      var x = p.getX(i) / radius, y = p.getY(i) / radius, z = p.getZ(i) / radius;
      // Coordinate-based deformation keeps coincident vertices together (no split seams).
      var bulge = 1 + .12 * Math.sin(x * 3.1 + seed) * Math.cos(z * 2.7 - seed);
      p.setXYZ(i, x * radius * bulge, y * radius * (.90 + .07 * Math.cos(z * 3 + seed)), z * radius * bulge);
      var light = Math.max(0, Math.min(1, (y + 1) / 2));
      colors.push(.65 + .35 * light, .72 + .28 * light, .77 + .23 * light);
    }
    geo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    geo.computeVertexNormals(); geo.computeBoundingSphere();
    return geo;
  }
  return {advancePhase: advancePhase, damp: damp, grassHeight: grassHeight, stoneGeometry: stoneGeometry};
});
